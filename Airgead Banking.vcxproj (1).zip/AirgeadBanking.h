//not sure about the pragma. It was there when I started so I just left it. 
#pragma once
#ifndef AIRGEAD_BANKING_H
#define AIRGEAD_BANKING_H

#include <iostream>
using namespace std;

class AirgeadBanking {
public:
	//declares constructor and functions
	AirgeadBanking();

	void getUserInput();
	void displayInput() const;
	void printNoMonthlyDepositReport() const;
	void printMonthlyDepositReport() const;
	//private variables entered by user
private: 
	double m_initialInvestment;
	double m_monthlyDeposit;
	double m_annualInterest;
	int m_numYears; 

};





#endif